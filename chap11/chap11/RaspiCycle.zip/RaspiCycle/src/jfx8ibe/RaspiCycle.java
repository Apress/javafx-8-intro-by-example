package jfx8ibe;

import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.List;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.application.Platform;
import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author Mark Heckler, @MkHeck
 */
public class RaspiCycle extends Application {
    private int SPEED = 1;
    private double SCREENHEIGHT;
    private double SCREENWIDTH;
    private Canvas canvas;
    private GraphicsContext gc;
    private Point2D startPos;
    private Point2D curPos;
    private Point2D newPos;
    private final List<Line2D> walls = new ArrayList<>();

    public enum Direction {
        LEFT, RIGHT, UP, DOWN
    };
    private Direction curDir = Direction.UP;

    private AnimationTimer animTimer;

    @Override
    public void start(Stage primaryStage) {
        StackPane root = new StackPane();

        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        SCREENHEIGHT = bounds.getHeight();
        SCREENWIDTH = bounds.getWidth();
        
        // Add screen boundaries to list of walls (coordinates) 
        // to check for collisions
        
        // Top wall
        walls.add(getLine(bounds.getMinX(), bounds.getMinY(), 
                bounds.getMaxX(), bounds.getMinY()));

        // Right wall
        walls.add(getLine(bounds.getMaxX(), bounds.getMinY(), 
                bounds.getMaxX(), bounds.getMaxY()));

        // Bottom wall
        walls.add(getLine(bounds.getMinX(), bounds.getMaxY(), 
                bounds.getMaxX(), bounds.getMaxY()));
        
        // Left wall
        walls.add(getLine(bounds.getMinX(), bounds.getMinY(), 
                bounds.getMinX(), bounds.getMaxY()));
        
        // Define starting point for our Light Cycle (bottom center)
        startPos = curPos = new Point2D(SCREENWIDTH / 2, SCREENHEIGHT - 10);

        // Prepare the Game Grid (screen)
        canvas = new Canvas(SCREENWIDTH, SCREENHEIGHT);
        gc = canvas.getGraphicsContext2D();

        gc.setFill(Color.rgb(2, 2, 47));
        gc.fillRect(0, 0, SCREENWIDTH, SCREENHEIGHT);
        drawGameGrid();
        drawWalls(bounds);
        root.getChildren().add(canvas);

        Scene scene = new Scene(root, SCREENWIDTH, SCREENHEIGHT);
        scene.setCursor(Cursor.NONE);

        scene.setOnKeyPressed( (KeyEvent event) -> {
            handleKeyPress(event);
        });

        primaryStage.setTitle("RaspiCycle");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        animTimer = new AnimationTimer() {
                @Override
                public void handle(long now) {
                        runLightCycle();
                }
        };
        animTimer.start();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private void drawWalls(Rectangle2D bounds) {
        gc.setStroke(Color.LIGHTBLUE);
        gc.setLineWidth(2);

        // Top wall
        gc.strokeLine(bounds.getMinX(), bounds.getMinY(), 
                bounds.getMaxX(), bounds.getMinY());

        // Right wall
        gc.strokeLine(bounds.getMaxX(), bounds.getMinY(), 
                bounds.getMaxX(), bounds.getMaxY());

        // Bottom wall
        gc.strokeLine(bounds.getMinX(), bounds.getMaxY(), 
                bounds.getMaxX(), bounds.getMaxY());
        
        // Left wall
        gc.strokeLine(bounds.getMinX(), bounds.getMinY(), 
                bounds.getMinX(), bounds.getMaxY());
    }
    
    private void drawGameGrid() {
        int boxSize = (int) (Math.min(SCREENWIDTH, SCREENHEIGHT) / 10);
        int i;
                
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(5);

        // Draw horizontal lines
        i = boxSize;
        while (i < SCREENHEIGHT) {
            gc.strokeLine(0, i, SCREENWIDTH, i);    
            i += boxSize;
        }
        
        // Draw vertical lines
        i = boxSize;
        while (i < SCREENWIDTH) {
            gc.strokeLine(i, 0, i, SCREENHEIGHT);    
            i += boxSize;
        }
    }
    
    private Line2D.Double getLine(double x1, double y1, double x2, double y2) {
        return new Line2D.Double(Math.min(x1, x2), Math.min(y1, y2), 
                Math.max(x1, x2), Math.max(y1, y2));
    }
    
    public void handleKeyPress(KeyEvent event) {
        boolean isNewDir = false;
        
        if (event.getCode() == KeyCode.LEFT &&
                curDir != Direction.LEFT) {
            curDir = Direction.LEFT;
            isNewDir = true;
        }
        else if (event.getCode() == KeyCode.RIGHT &&
                curDir != Direction.RIGHT) {
            curDir = Direction.RIGHT;
            isNewDir = true;
        }
        else if (event.getCode() == KeyCode.UP &&
                curDir != Direction.UP) {
            curDir = Direction.UP;
            isNewDir = true;
        }
        else if (event.getCode() == KeyCode.DOWN &&
                curDir != Direction.DOWN) {
            curDir = Direction.DOWN;
            isNewDir = true;
        }
        else if (event.getCode() == KeyCode.DIGIT1) {
            SPEED = 1;
        }
        else if (event.getCode() == KeyCode.DIGIT2) {
            SPEED = 2;
        }
        else if (event.getCode() == KeyCode.DIGIT3) {
            SPEED = 3;
        }
        else if (event.getCode() == KeyCode.ESCAPE) {
            animTimer.stop();
            Platform.exit();
        }
        
        if (isNewDir) {
            // User sent Light Cycle in a new direction...
            // add the wall (light trail) to the list & start a new one
            walls.add(getLine(startPos.getX(), startPos.getY(), 
                    curPos.getX(), curPos.getY()));
            startPos = curPos;
        }
    }
    
    private void runLightCycle() {
        calculateDestination();
        gc.setStroke(Color.YELLOW);
        gc.setLineWidth(5);
        gc.strokeLine(curPos.getX(), curPos.getY(), newPos.getX(), newPos.getY());
        curPos = newPos;
        checkCollision();
    }

    private void calculateDestination() {
        double newX = 0;
        double newY = 0;

        switch (curDir) {
            case UP:
                // X doesn't change, only Y
                newX = curPos.getX();
                newY = curPos.getY() - SPEED;
                break;
            case DOWN:
                // X doesn't change, only Y
                newX = curPos.getX();
                newY = curPos.getY() + SPEED;
                break;
            case LEFT:
                // Y doesn't change, only X
                newY = curPos.getY();
                newX = curPos.getX() - SPEED;
                break;
            case RIGHT:
                // Y doesn't change, only X
                newY = curPos.getY();
                newX = curPos.getX() + SPEED;
                break;
        }
        newPos = new Point2D(newX, newY);
    }

    private void checkCollision() {
        System.out.println("Current Position: (" + curPos.getX() + ", " + curPos.getY() + ")");

        walls.stream().filter((line) -> (
                (line.getX1() <= curPos.getX() && curPos.getX() <= line.getX2()) &&
                (line.getY1() <= curPos.getY() && curPos.getY() <= line.getY2())))
            .forEach((line) -> {
                animTimer.stop();
                System.out.println("COLLISION!");
                Platform.exit();
            });
    }
}
