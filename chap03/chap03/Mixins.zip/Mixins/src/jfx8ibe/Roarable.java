package jfx8ibe;

public interface Roarable {
    default void roar() {
        System.out.println("Roar!!");
    } 
}
