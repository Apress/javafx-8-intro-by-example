package jfx8ibe;

public interface Meowler {
    default void meow() {
        System.out.println("MeeeeOww!");
    }
}
